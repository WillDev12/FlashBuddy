const express = require('express');
const path    = require('path');
const fs      = require('fs');
const { marked } = require('marked');

const app  = express();
const PORT = 3000;
const GITHUB_REPO = 'WillDev12/FlashBuddy';
const DOCS_DIR    = path.join(__dirname, '../docs');

// ── helpers ──────────────────────────────────
function esc(s) {
  return String(s ?? '')
    .replace(/&/g, '&amp;').replace(/</g, '&lt;')
    .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

function shell(css) {
  return `<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<link rel="icon" type="image/png" href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAgAAAAIACAYAAAD0eNT6AAAACXBIWXMAAA7DAAAOwwHHb6hkAAAAGXRFWHRTb2Z0d2FyZQB3d3cuaW5rc2NhcGUub3Jnm+48GgAAIABJREFUeJzs3XuYXGWdL/rvb1X1JQnhjiTcI4YkNBiBJl1V3Z1QSQeYjKOeGYl7RpGAyuP2jDPObTvObPfOmatnzoxnHGePzyCXAKPuE3ScUUQhnRTpVNWqblsgYEJCEBAIN7mZkL5Wrd/5ozsxhE7S9fZa9a7L9/M8Pg8P8tb6Qrrr/a33KiCiUPh4effZ4ukV4qEdgksBnAXgbAAnA5gz+Y+9KcCLCrwMYLeIPqziPHRg70UP3bNWarayE1H0iO0AREl1Y9+eM+B4K1W9VYD0AFhg/GGK1yC4XxTffeu02vfuaWsb8y8pEcURCwCiBrl5cHD2+NCcbg/S4zi6SlWWAnACeNQvBHIXvNRX7ljxnucC+HwiigEWAEQBuW6jpk6Yv6fdg9cjQA+ALICWBkYYVZWvpxz929u7Fr/QwOcSUQSwACDy0U3bnnh3DbUemRjS7wFwiu1MAIYA/MWBFxf9PdcJENFBLACIZmBdYcc8bUqtEkiPqvYIcI7tTMcwoE7qd+7sXPgz20GIyD4WAER1uHlwcHZ1+MScB+/gG/7liNbv0T5RfOKO5Yu/bTsIEdkVpS8uooZbXyikn07N7xCRHoX2CNABoMl2rhlSAF/Y0L34/7YdhIjsYQFAdIQj5vFXY2IffuwI8E93dC36HETUdhYiajwWAJR4nyzsOafWVF3lQXpEsQrAfNuZGkUVf3/n8sV/YjsHETUeCwBKnOvv3z6nafasbITn8X0mf7She9GXbacgosZK8JceJcV1O3Y0z3ndySlk1cSwvl4JIGU7V4h4Av3gHd1L7rUdhIgahwUAxdIR8/jXADjRdqaQewNVvXxDfskztoMQUWOwAKBYWFd4/AJJOT0q3ipAVgE4w3amqFGguKBr0Yr1Ip7tLEQUvLTtAEQmbirumgt1Og6bx79CoWBNa06ArqeLuz4J4BbbWYgoePy2pEi4rvzcrLne0BWeaqdCewC5SljABuGNmpNefHfne16xHYSIgsUvUAql9arO08VdlwkmD+CpHejygFYAENatQTol7VX/HMDv2w5CRMHiNymFxtsW7ilWQnCa7UwJNeIILuQNgkTxxhEAsub60pPvStVqKyHaA6DHg3f+obd7lqY2tXqqfwTgj2wHIaLg8GuWGmaKi3QuA+BYjkVTe/NAas5Z9+TOHbYdhIiCwREACsx1GzU1e/6u9x2cxx8blm7Aa7Gdi6bl5BNqb30IwLdsByGiYLAAIF9dv/WJJelUbZVCeoDdV0HlJIAL96JIITeABQBRbPFbmWbk+tKT70p51RWTb/nXADjfdibyzciB1JxTOQ1AFE8cAaC6vOMiHa96OQCZOISHYqZ1bm24E0Cv7SBE5D8WAHRMR87jC2S5B6/Zdi5qDA+1VWABQBRLLADoHd62H192X815/OSaWMuBL9jOQUT+4zc6YV1hxzykU90C6fGgawQ4x3YmCg2vuSpn3pJf9KrtIETkL44AJNBnCjtOGEk3ZQ7bj39oHp8VIR3BGU/pVQC+bTsIEfmLBUACrC8U0k+n5y09OI8/BFkBeE22c1E0KLAKLACIYocFQEwdPo//DHCNACcCnMen+k2uAyCimGFvEBMf69s5Py1O1+Rb/vsBnGU7E8VHzcO7716x+GnbOYjIPxwBiKiP9z9+mjMmKwXoUqATwBUAwP34FIS0yCoAt9rOQUT+YQEQEdeVn5s1tzbceWjh3tjERTrs7qkRVDwWAEQxwymAkFqv6jxd3HXZYQfwdAFotZ2LkkmBVxd0LTpzvYhnOwsR+YMFQIi87QCeiZXXp9rORHSI41y2ofOiR2zHICJ/cArAohv79pyhUrtKID0qerWn3gVcpU9hJVrrAcACgCgmWAA00M2Dg7OrwyfmDs7jK2q/ukiHk/kUcqqyCsDf285BRP7g62aAprhIpxtAi+1cRIaG5u5PnfrVNQtHbQchopnjCIDP3j6Pv3s1ICcDPICHYmH2/rnVLIAHbQchopljATBDn6w8dmZ1vGn55Fv+tR6889jZU1wpZBVYABDFAguAOl1///Y5TbNnZQ/O41fHf3WRDlHcTe5Q+aLtHEQ0c3xVPY4jL9IRyHIAzbZzEVlSG8PYGd/sfu8btoMQ0cxwBGAKb7tIR3C1KE4COI9PBCDVrC0rAPyH7SBENDMsAACsK+yYh3SqWyA9HnSNB++cQ509R/aJ3mbyemAWAEQRl8gC4DOFHSeMpJsyh87VP+wiHb7jEx2biPJ6YKIYSER/N8U8/goATbZzEUWVeOnz7ljxnuds5yAic7EdAXjbPD5wrQBzAc7jE/lBZXwVgA22cxCRudgUAG87gEex0oN3Gjt7omCoIywAiCIu0gXAjVufPNdzqh8X4OMevIsOdfjs94kCJYpVUBWIcJksUURFsqtcV9p9JTz9MwAfAODYzkOURCnHu/S2zot/ajsHEZmJ1AjAuq2PXwpH/g6eXms7C1HS1dTpAcACgCiiIlEA3LzpZyeNt47/hQd8RiKSmSjuJq8H/kfbOYjITOinAG7c9kSHwvsmgHfbzkJEb7O/edZbp93S3j5uOwgR1S+88+eqsq6464sKrwR2/kRhNLc6MrfDdggiMhPK4fTP3renZV9p961QfMx2FiI6Ok+9HgBF2zmIqH6hGwG4qbhr7v65tU3Czp8o9BSyynYGIjITqgLg5sHB2Z7iewC6bWchomnJfLSy50TbIYiofqEpAG4eHGwaGzrhuwCusp2FiKZHgHTzeHW57RxEVL/QFACjQ3O/DMHVtnMQUX0mtwMSUcSEogC4sfj4DSL6u7ZzEFH9VMDrgYkiyPo5AJ8o7Ty/5jmPYfK2PiKKHK2qd/a/Lb/4RdtBiGj67I4AqErNc/4V7PyJokya4HAagChirBYAN5R2XwfgGpsZiGjmFMJpAKKIsVYA3Dw42CSKv7L1fCLykSgLAKKIsVYAjI2c8AkAC209n4h8dfa68u7FtkMQ0fTZKQBUBYrPWXk2EQVCPI+jAEQRYqUAuGHbEysBLLLxbCIKBs8DIIoWKwWAiPdJG88logAJ8usLhVBeMEZE79TwAuDmwcEmQK5t9HOJKGCKk55pOrPddgwimp6GFwAjIyd0ATi50c8louCJOlwHQBQRDS8ARLGy0c8kosZQgOsAiCKi8QUAsLTRzySihsldf//2ObZDENHxNX4RoODShj+TiBqlOTW7pdt2CCI6voYWAOsLhTQU5zfymUTUWMJjgYkioaEFwAs462SE4AZCIgqOQrkOgCgCGloAjDm1Uxr5PCKyYun1pSffZTsEER1bQwuAGtI8JIQo/iRVq3G3D1HINbQAkNT4gUY+j4jsUIfTAERh19A38iYHb9VqjXwiEdkggPFCwEql9EHPE3EcZ0smk9nnZy4i+pXGLshTlXXF3W8BmN3Q5xJRw6VStYW35dqerLed67rrAL0DQA3AI4D0Auhtamra2t7ePu53TqKkauw5ACIK4ImGPpOIrKh5KaNRAFXdNPmXKQBXAPp5QDeNj4+97rrlTa5b+nylUrnYv6REydTwLXk3bNv9TYH+dqOfS0SNpcC37+xefJ1JW9ctPw5g8TE/X/EUgF4AvbVarbe7u/sNk2cRJVXDV+U74pVVhQUAUcwJsHK9qrNexDNo3ovjFAAieDeAmwHcnE6naq5bPjRdcOKJJ/a1tbWNGTyXKDEaPgJwU3HXIk+xq9HPJaLGcwRX3t61eLDeduVy+UMi+O4MHn0AgAtor0iqN5PJ/GQGn0UUS1ZO5Vu3bdczAI8EJoo9kS9s6Fr0pXqbDQ4OnjQ+PvYq/BulfFoVmzAxsrA5l8u97tPnEkWWrQLgVgCfsPFsImochfbe2b1ktUlb13VdQDN+Z8IRuws4XUBJ1fjbAAEIdLON5xJRYwmk67ryc7MMm/f6GuZX3ra7YN++Xx6+u+CKgJ5JFDpWjuatOk2bU15VwYuBiOKudW5tuBNmnflmAP/d5zxTmQOgB5AeVQ/lcvlFx0HR83AvgHs5XUBxZa0DXrdt1yMAltp6PhE1in5pQ/eSL9TbaseOHc379v3ydUx00LZ4AB4+OF3wxhtvbFuzZs2oxTxEvrEyBQAAMvELRUQxpxCjA4Ha2trGRFD0O0+dHBw2XXDKKSe/bbpAVTmKSZFl7Yf348Xdv+ao3mfr+UTUMF5zVc68Jb/o1XoblsvlPxHB3wURyicviWAbgN50uvr99vblL9oORDRd1q7nbW3dv3Vs+IRRAC22MhBRQzijKW8FgO8YtA37SOE8VVwH4Lrx8fTXXLfM6QKKDKvDV+u27XoQwAqbGYgoeCr42p1diz9TdztVqVTclwGcEUCsoA0BKB88jKijo+MhmbgPhSgUrK0BAAAIuB2QKAFEza4HnugwdYvfeRpkNiZ2F3xJ1RusVNwXK5XyxkqlfHOxWDzLdjgiqyMAHy89nnU8KdvMQEQNUtUFG/JLnqm3meuWPgXILQEksm0nIN8HpwvIEmtrAABgeO/igTnzd78J4GSbOYgoeNokqwDcVm87z8MDjt2xyqBcDOjFAD5/yiknD7lumdMF1FDWt7CsK+76Dyg+aDsHEQVLId+6s3vR75i0dd3ykwAu9DlSmL0sgj4AvZ6HH+Ryub22A1H8WB0BAAB4uhkiLACIYk9Xm14PLIJe1UQVAGce3F0gApTL5adE5F4A3x8ZGSnm8/kR2wEp+qwPrNU0FfZtPkTkAwFOf7b4xKUmbT0v2QuGRfBuQH8P0E2trS08jIh8EYofnBu27XpOgHNs5yCiYCn0j+/sXvIP9bbr7+8/zfNqryAELy0h9IoItoLTBVSnUBQA6/p2b4DoDbZzEFGwBPjhHd2L15i0dd3yIADe1nccqngKQK+I3DsyMrKJ0wV0NOGopnkeAFEiKLDis/ftMTz9k/eHTIcI3i2CmwH9HqcL6FhC8cOwrrBjHtKpFxCSPEQUHFG96o7lS7bW265SqaxW9R4IIlOCHJouAJz7MpnM87YDkT2h6XDXbdv9U0DbbOcgooAp/nLD8sX/o95mhUKhtbW15XUAswJIlUgHpwsA9Hqe96Ourq79tjNR44RjCgAAoBzeI0oAgdmxwJNz2SWf4yTawekCEWxMpZyXXdf9geuWPjUwMDDPdjYKXpgKAK4DIEoAFSxbV3ja6PRPVUT1XoAomAXoGkBuqdWqeyfWDri/wXUD8RWaAsAReRDAuO0cRBS4lKRGjW4BTaW8TX6HoSk5AHoA/V6l4g5WKsW87UDkv9AUALd3Ld4PYMB2DiIKnjqyyqTdsmWdDwF43ec4dGyXqzpbXLf0n8Vi8TzbYcg/oSkAJnAdAFESiKrp9cAeIAW/89B0yAdSKeexSqX0MdtJyB/hKgDE4ToAogRQYMknC3tMT//ki4I9J6rK3a7r3lIoFOzfJUMzEqoC4ILxF1wA+2znIKLg1ZqqRtMAIsIXBev0U62tLT8cHBw8yXYSMheqAmB9Pl+F6DbbOYgoeKpm6wAymcweAM/4m4YM9IyPj22qVCon2g5CZkJVAACAeJwGIEqI1TDfYsbviXC4EvB+tH379jm2g1D9QlcAqHqc3yNKhnk3lHZebNJQhAuGw0IV2QMHDnyD5wVET+gKgA3LF/8UwIu2cxBR8ERTRrsB0umWXgCez3HIkAg+WKlUvmA7B9UndAUARBQAt/kQJYPROoD29vZXRfCo32FoJvQvyuWy0QFPZEf4CoAJnN8jSoarbh4cbDJpqMrdACGTEsHXy+UyL2uKiFAWAOlqild+EiXD3NGhE5aZNFTlOoAQWgig7pseyY5QFgC35hc+D+AJ2zmIKHgiYrQOoLm5uQ/AqM9xaIZE8If9/f0LbOeg4wtlATCJ1T1RIqjpOoAhABWfw9DMNXuexwWBERDeAkB4PTBREiiQ/Whlj+FhMpwGCCddVyqVzredgo4tvAXAeOsWADXbMYgoWAKk02PabdLW87hgOKSaHAefsh2Cji20BcCG/II3AfzEdg4iagCnZjQNsHfv3gERvOl3HPKDfGLQcIcHNUZoCwAAgAiH94gSQGC2EHDt2rU1AA/6m4Z8Mm98fNzoz5UaI9QFgNS4DoAoERSXfKxv53yjpipb/I5Dvnm/7QB0dKEuAN46vVYEcMB2DiIKnKQcZ6VJQ1Xd5HcY8ouyAAixUBcA97S1jUFRsp2DiBpAzY4FzuVyuwA873Ma8sd5ruteYDsETS3UBQAAKI8FJkoEAa6eQXN+T4SUiHeF7Qw0tdAXAA54PTBRQpx9U3HXIpOGvB44vFRxue0MNLXQFwDndy95BMAvbOcgouDV1Gw3gOM09QJQn+OQD0SExwKHVOgLgPUinvB6YKJEcOAZrQNYtmzZS6rY6XcemjlVnGU7A00t9AUAAHjgdkCiJFBI/rqNmjJszmmAUFKj7Z0UvEgUAFIFrwcmSoaTT5i/p92koYjwRSGUpMV2AppaJAqADfklzwB4ynYOIgqeB89oHUCtVnsQwLi/acgHYjsATS0SBQAACHgsMFESODA7D6Crq2s/oP1+5yGKq8gUAB6vByZKBAU6r79/+xzD5vyeCJ9XbQegqUWmANAm3QzAs52DiALXnJ7V3GXS0HH4ohA+8pLtBDS1yBQAd3UseQ3AI7ZzEFHw1BGjaYBUqrUCYL/PcWgGRJQFQEhFpgAAAOE2H6JEEKjRQsD29vZxVfT5nYdm5FHbAWhqkSoAPA7vESWCqrzvxr49Z5i05XbAcBHxHrKdgaYWqQJAxlr7AIzYzkFEgRM4ntH1wJ7n8Xrg8FDV9HbbIWhqkSoANuQXjEBQtp2DiIKnanYscC6X26GKF/3OQybk0Uwms892CppapAoAAIDHaQCiZBCj64FFREV0i99pqH6qytGYEItcAeDB4UJAomQ4/4bSngtNGorwPIAwcBwWAGEWuQJg+KWLfgLgdds5iCh4jlaNdgN4nvD+EPtG0umWou0QdHSRKwDuWSs1QB60nYOIgqdqdh5ALpfbK4LdfuehupTa29uHbIego4tcATCJw3tESaBYuV7V6HvK83huiF0c/g+7SBYAHjz+YhMlgeC0p4u7LjNszRcFqxwWACEXyQLgru4lT0DwjO0cRBQ8gRitAxgdHS0AqPkch6bntUwmw6PbQy6SBQAAQMFtPkSJYLYOIJ/Pvwlg0OcwNC3aKyK8vC3kolsA8HpgooTQ7uvKz80ybMvpQgtUhcP/ERDZAqAmTb0A1HYOIgpc6+zqUM6kofBFwQrexxANkS0A7u58zysAHrOdg4gawmgaYO7cU0oADvichY5Jn8hms8/YTkHHF9kCYAKH94iSwPR64La2tjER8DCaBuLwf3REuwAQh8NMREkguPwT5R2nmjT1PG4HbCQe/xsdkS4AagdGtgIYtZ2DiAKXqladvGFbjhQ2TjWdbnnQdgiankgXAHdfs/QARPtt5yCiBnDMtgNms9lHAPzC5zQ0tf729vZf2g5B0xPpAgAA1OM0AFESiMJoHYCIKMDrgRuD8/9REvkCwFEeC0yUEAvXFR6/wLAtXxQaQJXz/1ES+QLgfO+lAQg45ESUANpkNg3geeD1wMHb39zc/GPbIWj6Il8ArM/nq+Jhq+0cRNQAhtcDd3Z2/hzAz3xOQ4dRxZb29vZx2zlo+iJfAACAJxzeI0oGXW16PbAIdwMEjMP/EROLAsDRFH+xiRJAgNOfLT5xqUlbngcQrFQqxQIgYmJRANyxfOFOAHtt5yCi4NXgGe0GSKVSWwDwhrpgPN/R0fGE7RBUn1gUAJO4zYcoARzD64E7OjpeA/Cwz3Fowv22A1D9YlMA8NYvomRQYMVn79vTYtZaOF0YCO7/j6L4FAD8ASRKitlvnVDNmDTkNbWB8MbHxzkCG0GxKQBu71r8ggCP285BRMFTw2mA4eHhbQCGfY6TdI8sX76cRy1HUGwKAABQ4fAeURIIzI4FzufzIwDKPsdJOI6+RlWsCgDxuA6AKAlUsGxd4emTjdoqtwP6icf/Rle8CgAHWwDwJCqi+EtJanSFSUNV5UihfziiEmGxKgBu71q8XxSDtnMQUfDU8HrgvXv3PgTgdZ/jJJIq+nK5HNdURFSsCgAAUPC4T6IkEFWjdQBr166tAVLwO08SOQ6P/42y2BUAAq4DIEoCBZZ8srDnHMPm/J7wgUiNBUCExa4AeOs0z1XgLds5iCh4taaq0TSAcMeQH15ZtqzrUdshyFzsCoB72trGHGCb7RxEFDw1vB44k8nsAfCMv2kSp1dE1HYIMhe7AgAAPE4DECXFaqiKYVt+T8wI9/9HXSwLgBQcDu8RJcO8G0o7LzZpyPMAZiaVSvG/X8TFsgC4veuiRwG8ZDsHEQVPNGW0G6C5uXkTeD2wqceXLVv2nO0QNDOxLAAgosptPkRJYbQOoL29/VVAHvM7TDJw+D8O4lkAAACvByZKiqtuHhxsMmzL6UIDPP43HmJbACi4P5UoIeaODp2wzLAtXxTqV3Ucp892CJq52BYAd3W1PQtgj+0cRBQ8ETFaB9DU1LQVwKjPcWJNFW4mk9lnOwfNXGwLAABQ4fAeUTKo6TqAIQAVn8PEGo//jY9YFwDg9cBEiaBA9qOVPSeatBXhNEB9PBYAMRHrAkBqrZsB1GznIKJgCZBOj2m3SdtajdcDT5cI3hweHueNqzER6wJgQ37Bm1A8ZDsHETWAUzO9HnhABG/6HSeOVFHI5/NV2znIH7EuAABAwUs/iJJAYLYQcO3atTXPw1a/88QT9//HSewLAHCbD1EyKC75WN/O+SZNRYTfE9PA/f/xEvsCQGrNJQDDtnMQUeAk5TgrDdtypPD4fp7L5Z60HYL8E/sCYEN+wQggRds5iKgB1OxY4Gw2+ziA531OEzPygO0E5K/YFwATuB2QKAkEuHoGzfk9cQwc/o+fRBQACm7zIUqIs28q7lpk0lB4f8ixeM3NzbxgLWYSUQAs6Fr8sAKv2s5BRMGrqdluAMdp2gRAfY4TC6p4aOL2RIqTRBQA60U8AVi9EiWAA89oHcCyZcteUsVOv/PEgYhy/j+GElEAABzeI0oKheSv26gpw+acLpySw/n/GEpMAeBJmr/YRMlw8gnz97SbNOR5AFMaeuONN1zbIch/iSkA7uxc+DMAT9vOQUTB8+AZrQOo1WoPAhj3N03kbV2zZg2vTI6hxBQAE7gbgCgJHJidB9DV1bUfwIDPcSKOx//GVaIKABGHw3tECaBA5/X3b59j2JovCofxPF7/G1eJKgBqTV4vAM92DiIKXHN6VnOXSUPH4YLhw7yUy+V22A5BwUhUAXBXx5LXRHS77RxEFDx1xGgaYGho3AWwz+c4kaSKTSLCsxFiKlEFAMDrgYmSQqBGCwHz+XxVFdv8zhNFjsPjf+MscQWAeBzeI0oCVXnfjX17zjBpy+2AAABNp2t8YYqxxBUATbMPbAPALS1E8SdwPKPrgVW5EBDAjvb25S+aNHRd94ZCoZD2OxD5K3EFwC3t7UMClG3nIKLgqZodC5zNZn+qCqPOL0aMhv83btyYAvTLLS0t32IREG6JKwAAwOO1n0QJIUbXA4uIiugWv9NEi9n+/3POOecKAKeK4MOzZrV8k0VAeCWyAHDgcHiPKBnOv6G050KThiKJflEYGxkZMVoIKSKrD/61Kq5rbW35BouAcEpkAfDWiwsHAbxhOwcRBc/RqtFuAM+TJN+AV87n82+ZNdXVR/yNta2tzf82MTVAYZLIAuCetVIDsNV2DiIKnqrZeQC5XG6vCHb7nScazIb/t2/fPgdAZorP+8i55559q6omss8Jq8T+YfB6YKKEUKxcb9jxeF4yrwc2Pf53eHj/CgAtU/+/sq5SqbAICJHE/kGow3UARIkgOO3p4q7LDFsn8UXhjb179z5k1tQ5cvj/CHpjf7/7dRYB4ZDYP4QNuUW7ADxnOwcRBU8gRusARkdHCwBqPscJNVVsXrt2rdG/s+fhOAUAoIqbKpXyv6qqmDyD/JPYAgAAwNO+iBLCbB1APp9/E8Cgz2FCzXHM9v8PDAzME8HF0/un5ZOVSoVFgGWJLgB4LDBRUmj3deXnZhm2TdR0YSpldvxvtVq9GkAdHbp+qlKp/COLAHsSXQCkmsc3AeBNV0Tx1zq7OpQzaZiwBcM/u/LK7qdMGh6+/3/69Pf6+90vmzyPZi7RBcCtmUtfVoB3XRMlg9E0wNy5p5QAHPA5S1gZDf+rqqiq0X9fVXzOdcssAixIdAEAAKLJ3OZDlDSm1wO3tbWNiaDod55wMtv/77ruJSKYP4MH/4Hrlv5hBu3JAAuAZA3vESWX4PJPlHecatLU8xKxHbCmqg+aNDQb/n/Hp/xhuVz+f2b+OTRdLABEtgIYt52DiAKXqladvGHbJIwUDuZyudfNmr7j+F8jIvjjSqX8d358Fh1f4guA27sW71eg33YOImoAx2w7YDabfQTAL3xOEzJmw/87duxoBtDtVwpV/Inruv/Tr8+jo0t8AQAAAk4DECWBKIzWAYiIAvG+Htj0+N/9+9/oBDDH3zS6vlIpf9Hfz6QjsQAA4AiPBSZKiIXrCo9fYNg2zi8KB375y18ajoQe7/hfM6r4C9d1/zyIz6YJLAAAnDf+QgXAPts5iCh42mQ2DeB5iO31wKp4cM2aNaMmbadz/K85/SvXdf8suM9PNhYAANbn81WF9NnOQUQNYHg9cGdn588B/MznNKFgevxvf3//aSK43O88b6d/XamU/zTYZyQTC4BJ3A5IlAwCXQXD42dF4robwDEqAGq12ko0oB9Rxd+6bunzQT8naVgATEqJF9NfbCI6wrtuKj7xXpOGMT0P4IWOjo7HTRr6s/9/2k/7W9d1P9u458UfC4BJt+WW7ADwou0cRBS8Gjyj3QCpVGoLAM/nOLZtmtjlYMLsdEVDAuhXyuXy7zbwmbHGAuAgEVWJZXVPREdwDK8H7ujoeA3Awz7Hscxs/3+5XH4PgAU+hzlwcRl5AAAgAElEQVQeEcE/VSqlzzT4ubHEAuAwvB6YKBkUWPHZ+/a0mLWWOE0XalPTuNH5Bo0d/n/7o1Xln13X/a+Wnh8bLAAO46XNFsIQUeTMfuuEasakoYjE6UXhsfb25YZTn/4c/2tIAP1frut+2mKGyGMBcJi7cov2AthlOwcRBU8NpwGGh4e3ARj2OY4lZsP/GzduTAG4yt8sdRNA/6VSKd9sOUdksQA4gmqshveI6CgEZscC5/P5EQBln+NYoapGBcB55511JYBTfI5jQlTxtXK5/HHbQaKIBcARJN7HfRLRJBUsW1d4+mSjthqL74nROXPmFE0aep5ztd9hZsARwe2VSuljtoNEDQuAIzSPpgsKVG3nIKLApSQ1usKkoarGYaSwuHTp0gMmDUWszv9PJaUqG1zX/ajtIFHCAuAIt6y+8JcCGbSdg4iCp4bXA+/du/chAK/7HKfBzIb/i8XiXEA6/E7jgxSgd5bL5d+xHSQqWABMQRGL6p6IjkPU7CCbtWvX1gAp+J2nscx2PaVSqasANPmbxTcpEdxVqZT+i+0gUcACYAoCngdAlAQKLPlkYc85hs2j/D3xWiaTecSsqRe24f8jpVTl31zX/YjtIGHHAmAKB071ygCM5saIKFpqTVWjaQCRKO8Y0l4RMTzS2NoBQPVIAXp3pVL6oO0gYcYCYAr3tLWNAdhmOwcRBU8NrwfOZDJ7ADzjb5rGUDU+/vdsAIt9jhOUJlXZ6LruB2wHCSsWAEfB64GJEmO16fXAiOg0gOlpho6jYdr+Nx3NgN7juu5v2A4SRiwAjkIlFeHhPSKqw7wbSjsvNmkYzfMA9IlsNvuMWdtIDP8fqRnQb5fL5ffbDhI2LACOYkNu4XYAr9jOQUTBE00Z7QZQ1c0ADK/StcN0+F9VRRV5v/M0SLMIvt3fX/p120HChAXA0YgooEa3ZBFR5BitA+js7HwFkEf9DhMkxzHb/18ul5cCmOdznEZq8Ty5p1wuG/1ZxxELgGMQdSI4vEdEBq66eXDQdG97lKYLq+l0y4MmDS1e/+unWSL4Xn9/aaXtIGHAAuAYnFSN1wMTJcPc0aETlhm2jdKLwkB7e/svTRqG8PhfU7M9T75fqRSjOp3hGxYAx3Bb58U/V5UnbecgouCJiNE6gKampq0ARn2OExCz4f9CodAKSJffaSyarerc67ruVbaD2MQC4DiExwITJYQazQ23t7cPAaj4HCYgZsf/tra2dgGY5XMY22YDem+5XDa6ECoOWAAcB68HJkoGBbIfrew50aStSCS+J/Y3NTUNmDUN/fG/puaI4AelUmm57SA2sAA4Didd2wLA8MhMIooKAdLpMe02aVurRWGkUAvt7e3jZm1jsQDwaOY4jnzfdd0w3nAYKBYAx3Fbru11BR6ynYOIGsCpmV4PPCCCN/2O4yfT/f+Dg4OnA1jqc5ywORHQ+8vlsulC0EhiATANXAdAlAwCs4WAa9eurXketvqdx0+e5xkVANXqaA+S0Vec5Di4v1QqXWk7SKMk4Q91xhykojC/R0QzpbjkY30755s0NT1fv0Ge7+rq2m3WNNbD/2+jipNTKXmgv7/YbjtLI7AAmAav2lQEMGw7BxEFTlKOY3pITGhHCkXwgGlbVSTq0BxVnOx5zgOVSuUK21mCxgJgGjbkF4wotGQ7BxE1gJodC5zNZh8H8LzPaXxitv+/WCwuAnCBv1ki4RRV74flcvlS20GCxAJgmkR4LDBREggwkytvw/g9obUajO41cRwnMcP/UzhDBJtLpdIltoMEhQXAdEVjny8RzdzZNxV3LTJpKKJh/J54ZOLSovrF6PhfU2c4jmweGCi22Q4SBBYA03RB7qKfKPCq7RxEFLyamu0GcJymTQjd9cDGx/+mAUnsKXmHeVet5mypVCoX2w7iNxYA07RexBMJ9zYfIvKHA89oHcCyZcteUsVOv/PMjPHxvx0ATvI5TFS9S9Xb4rruEttB/MQCoA7icRqAKAkUkr9uo6YMm4dpN8CIqukC5tge/2vqTEC3lMvlxbaD+IUFQB1UvTD9YhNRcE4+Yf4eo73g4ToPQLflcjnDLczJ2f9fh3ki2FQqlS60HcQPLADqsGHFxXsgeMZ2DiIKngfPaB1ArVZ7EIDhmfv+Mj3+t1gszgWQmBPx6nSO46Dw4x9ve7ftIDPFAqBeymkAoiRwYHYeQFdX134Ahrfu+UvVbAFgOi0rATT5HCdG5NxqNVXo7+9fYDvJTLAAqJMglNt8iMhnCnRef//2OYatQzBdqK/mcrlHTVp6Hof/p+E8z6s9GOUigAVAnZqqzibwemCiJGhOz2ruMmnoOPZfFERkk4gYfVdx//+0ned5tYLruhfYDmKCBUCdbskvehXAY7ZzEFHw1BGjaYChoXEXwD6f49TJ+Pjf8wC5yO80MXY+oJvK5fLZtoPUiwWAAYGEYHiPiIImUKOFgPl8vqqKbX7nqYfjNBl9TyX8+F9T7xFBoVgsnmU7SD1YABio8VhgokRQlffd2LfnDJO2lrcD7lq2bNlzJg05/G9sYSolkSoCWAAYaG3dvxXAqO0cRBQ4geMZXYeranMhoNnwv6o6gCTq+l9/yUXptLNlcLBvvu0k08ECwMAt7e1DACq2cxBR8FTNjgXOZrM/VcWLfueZHrPjf/v7+y8DYDTiQRNUsahaTRcGBgbm2c5yPCwATHEagCghxOh6YBFRETW6hneGqiJieG8Jj//1gyoW1WrV0BcBLAAMeRKGfb5E1ADn31DaY3T0q1h5UdBKJpMx2oHgeWAB4J/FtVr1/sHBwdNtBzkaFgCGhvcuHgDwpu0cRBQ8R6tGuwE8Tx7wO8vxmB7/Wy6XZ4kg53eehHvv+Ph4b39//2m2g0yFBYChe9ZKDbwemCgRVM3OA8jlcntFsNvvPMdievwvgOUAWv3MQgCgS1VroSwCWADMhGf/tC8iagDFyvWqRt+Xnte464FF8ObY2NiPzdry+N+gqOJ9nle7r1AonGA7y+FYAMxATVNcB0CUBILTni7uusywdcNeFFRRyOfzVcPWLACCtay1teW7O3bsaLYd5CAWADNw94qLHlfgeds5iCh4AjFaB+A4TtnvLEcjhouTK5XKmQAu9TkOvVPPvn2//IrtEAexAJghUaunfRFRw5itA+jo6HgFwFs+h5mS6aJDVe0BID7Hoal9ulwu/47tEAALgBmTUFz7SUTB05zJOgARUQBPBBDoSD/P5XJPmjX1jEY3yIwIvhaGa4RZAMyQ1mq9ANR2DiIK3Jxn3CdMb8nb5WuSKc1ky6HZ9AYZO1G19jXbIVgAzNCGfNtLgOy0nYOIgqeeXmHSTqQRBYDZboNKpXIxgHN8zkLHoYprXNf9DZsZWAD4gtMAREkgqpeYtFOVoO8E8JqamoyOHVat8e3fGu/vN27cmLL1dBYAvuB5AERJIIDRVa8iXqCnhqriofb29lfN2prddUB+kIvOOeec37T1dBYAPnBEHgQwbjsHEQXLMywAVJ1ACwDHgdHpf4ODg00iWOF3Hpo+EfyprWezAPDB7V2L9wMYsJ2DiIImJ5u0cpxawPeGeEYFwOjoaBZAqE6nS6DLXde93MaDWQD4husAiOJODPfKV6tieDrftAy9/vo+o8OGHMfh6X+h4H3UxlNZAPhFHK4DIIo/08NyZvma4u361qxZM2rYlgsAQ0E+oqoNP4iJBYBPLhh/wQVgdAc3EUXGfpNG6XSQBYDZ9b+FQuFkQK/0Ow0ZObu/v39Jox/KAsAn6/P5KkS32c5BRAFSvGTYMrACwPT639bW1pUArG1BoyPVrmr0E1kA+Eq4DoAozhx5xaSZKk7xO8qkl7LZ7E/NmvL43zBRdbKNfiYLAD/VeB4AUbyp4amfEtC579I7edeASVvu/w8VXdToJ7IA8NGG5Yt/CiDoE7+IyBJR52GTdqrBFACmw/+u614A4EJ/09AMmd4zYYwFgJ9EFAqj4ziJKPTGm2bte8ysqQZSADiOY/R9I6J8+w+fkwqFQkPPZGAB4DMRcBqAKI4E225pbx8ybO37Cm9V7MhkMs+btPU8cP9/CM2dm5rbyOexAPBZLTWTKzmJKKwE+kOTdqVS6UIAZ/ocx/j4340bN6ZEsNLvPDRztVoLC4Aouyu3aC+A3bZzEJGv1HG8/zBpmEoh53eYCWbH/5599tmXAzjV5zDkg1qt5jXyeSwAAsFjgYliRVC4Ldf2pElTVQSxvWtseHi8z6Qhj/8Nr3Q6/VYjn8cCIAAeeCwwUax48vUZtF7lW45fcfP5vGFnoSwAQqqlpcXopElTLAAC4FSbCwBqtnMQkS9+dkHthW+bNKxUKu8FJIDtXWbH/w4ODs4GAhmRoJl7fenSpQca+UAWAAHYkF/wJqCDtnMQ0cyJ6F+uz+cNb/PzfsvfNBNM9/+Pj4+vANDicxzyhTzR6CeyAAiI8FhgoshT4Kfnj7/0DeP2it/0M8+kN55//vmfmDXl8H94acMXj7MACEiN5wEQRZ0HxadN3/4rlWIGwCU+ZwIgW9auXWs6xcgCILS01OgnsgAIyEn7UmUApoeGEJFtIv/rzuWLjb+UVZ3P+hnnV59rNvw/MDAwD0Cbz3HIJyKpBxv9TBYAAfnqmoWjUBRt5yAiI48ecGZ/3rTx4GDffAAf9jHPIU1NNaMCwPPGVwMQn+OQP57JZDJ7Gv1QFgABUnAagCiC3lQn9Zv35M4dNv2A8fGmzwBo9jETAEAVT115ZfdTJm09Tzj8H1Ii+JaN57IACJADjwsBiaJlTB39yJ2dC39m+gF9fX1nAPr7foY6yPT4X1UVAD0+xyGfeB4LgNg5v3vJIwB+YTsHEU1LTRQfvbNzyYzu82hqSn0RQEBnupvN/5fL5TYRzPc7Dc2cCNxcLmd4y+TMsAAI0HoRj9cDE0XCCETX3rF8sdGBPwe5rnsBIDf7lOlINc+TgklDx3F4/W9IqcqXbD2bBUDAVJQFAFGIKfAWxPvAhq4l/z7TzxLR/xfBHbTzk1wu97pZU+Xwfzj9NJPJfN/Ww1kABEyq4PXARKElOyC1zIaui42G1g9XqZSuV8WH/Eg1NbPh/x07djQDWO5zGPKBKv5ERNTW81kABGxDfskzAIwXFBFRIFRV/hnV5vY7u9p2zPTDBgYG5qnKP/oR7GhUzc7/37//jU4Ac3yOQzP377lc7kc2A6RtPjwpBLJZoRfazkFEAIBHxdP/umHF4rIfH6aqjuu6t4rgVD8+7ygOnHTSSa5JQ1Xh8H/4vJFKpT9nOwRHABpAodwOSGTfs6L4zAXVF6+4Y8USXzp/AKhUyv9DBL/u1+dNRRUPtrW1jZm1FS4ADBlVfGLZsmXP2c7BEYAG8Jp1izMmHlhwETWe4DF48tUDp1XvvMewEz2aSqV0tar8dz8/cyqm+//L5fKpIrjM7zw0E/rVXK7zu7ZTACwAGuKujiWvrdu262EAV9jOQpQQz6rgByJyx4bORT8O4gGVSuViwPv/AKSC+PzDOY7xoWKr0IB8ND2q+MHo6Ngf2s5xEAuABhFgs7IAIAqEAm8BWhFIr0J77+xeYnhd7vSUSqULVb1NAE4O8jmTXrjyys6dJg1FZDVgbZE5vd3AnDlzPpLL5YxulwwCC4AG8RzdLJ78N9s5iOJAgaoA2wH0OnB607P2bb2lvX28Ec8ul8tni2ATgLMa8TwAm8y3inH/f0g87DipNUuXLj1gO8jhWAA0iIy19iE9OgKg1XYWooh66uAbfkrwo9u7Fu9vdIBisXie4+ABVSxo1DNFzBYRl8vl9wCNy0lH9bDjpFZ3dHS8ZjvIkVgANMiG/IKRdcVdZShW2s5CFBGHOnyvWbfc1bHE6hdoqVS6xHFwnyrObeBjNZ2uGd0qyuH/UAht5w+wAGgsTzdDhAUA0RQUeFWAgkJ7PU823b1i8dO2Mx1UqRTzqvJdACc1+NGPtbcvf9GsqfL6X7tC3fkDLAAayoPT60D/2nYOopAYVmjp4Fv+gq7FD68X8WyHOpyqSn9/+Q9V5W8ANFtIYDT8v3HjxhSAq/zNQnUIfecPsABoqOGXLvrJnPm7XwcCPTGMKKxqAB7B5MI9r9pUvDO/YMR2qKMZHBw83XXdDSIS6CE/x6IqRneJnHfeWVeq4hS/89C0RKLzB1gANNQ9a6W2btvuBwH9TdtZiBrkVwv3UrXNt+XaDG+za6xKpbhmfHzsFhGcbTHGaHNz8zazpg6H/+2ITOcPsACwYTMAFgAUV68A2KrQ3rSj99/WefHPbQeqR7FYPMtxnC+p4nrbWVRRam9vHzJp63lYLeJ3IjqOSHX+AAuAhvPg9TrgbybFxpBCy4cO4Ola/BAsXm9qavv27XOGht76XUC+iPDcnGc0/18sFueKION3GDqmyHX+AAuAhrure8kT64q7noHiAttZiAy8bR5/zn7Z9tU1C0dthzK1ffv2OcPDBz554MCBz4vIfNt5Duc4jtH8v+M4KwA0+RyHji6SnT/AAsAOxRYAN9mOQTRNh+bxUW3ZtCG/4E3bgWaqVCqdn0rJTUNDB/5PAKeFcLj8tY6OjodNGnL/f0NFtvMHWADYIboZKiwAKKTkZUD7FNrreE0/vGPFe6xfW+qH++67r+WUU075kKreJIIe1fDezimCLWK8JZL7/xsk0p0/wALAipo09aa0qgAXA1AoHFCo+6t5/EWRnMefysSNfbXLPU+uFsEHAD0phG/776Cqptf/ng1gic9x6J0i3/kDLACsuLvzPa+s27brMQDvtZ2FkufIi3T2nzred09b25jtXH6oVCpnep63HECPCK5V9c4DBFHo9A/nOGmjBYAc/m+IWHT+AAsAi7QXEBYA1CiH5vGrTan7v5FZuM92ID9MrN4fygLoAbRH1btcJPIja3s6OjoMj0Hm8H/AYtP5AywA7BFnM1T/0HYMiq0XARQV2qsp5wd35RbttR3ID4VCIT1r1qylqrUeQHqGhg4sh5UjeoMkRsP/qiqVisu7RoITq84fYAFgTe3AyNbU7JZRAC22s1As7Fdo/6F5/O4lP7EdyC8//vG2d9dqqR4APaq4WtU7Kc7LZ0zn/wcGiu8FUvP8zkMAYtj5AywArLn7mqUH1hUf74fKcttZKJKGATwEoOjA6T2vuvfB9fl81XYoPwwMDMyrVqvdmJjH//Vq1epxvI1Wq9VqW00aqqY4/B+MWHb+AAsAq9RzNosoCwCaDg/AwzjsIp0NIb5Ipx6FQuGE1tbWDCbn8Wu16hVRW7TnFxEMdHd3v2HSlsf/BiK2nT/AAsAqR71eFfm/bOeg0Dq0cM9r1i13dSyJxZfQkfP4AFYAypPrJhgN/xcKhVYRdPkdJuFi3fkDLACsOt97aeCZ1PxfQnGS7SxknwKvClBQaK/nyaa7Vyw2XAkeLqrq/PjHpSWe53RiYh7/WlVvbpzn8c05RgVAS0tLJ4DZPodJsth3/gALAKvW5/PVG/t2bVXBB2xnISvedpHOgq7FD683Pv0tXA5fuDexMt05zXamCNifTqf7TRpy/7+vEtH5AywArPMEmwUsABIiVhfpHG5wcPD0sbGxPCYW7q2uVrHAdqYIerC9vX3crCn3//skMZ0/wALAOkdTvSo12zEoOIfm8ccw1vvN7vcaLfAKm3K5PEtEOjG5cG98fOwykfCerR8NZvv/+/v7T/O82vv8TpNAier8ARYA1t2xfOHOddt27QUStdUpzl5UwWYH2ltznN64HMCzcePG1Hnnnfe+wxbudQHaajtXnJju/1etrgaExdfMJK7zB1gAhIJAfqDQm23nICNHXKSzODYX6RxxAE+PqncKF+4FZm8ul9tl1lQ4/D8ziez8ARYAoeCpfE+EBUBEvG0eP04X6ZRKpXeJyApMzONfU63ifNuZkkMeMG2pCh7/ay6xnT/AAiAUhtKztszxDnA7YDgpBD+Fh80Kp3dObXzrv+Tb3rIdyg+Dg4Ozx8fHc5icxwdwOfiKb4Xp8H+xWFwE4AJ/0yRGojt/gAVAKNyTO3d43bZdGwD8vu0sBAB4CcA2hfY2VdP33Zpf+LztQH44ch5/fHysG7yLIgxUVTebNHQch8P/ZhLf+QMsAEIjlar9c62W+izAldSNpsBbgFbiPo8PYLWqdzJf8sNFBNs7OztfMWurq/nnWTd2/pNYAITEbbm2J9dt2/UdANfZzpIAowKUVbVXJLX5wIsLB+9ZG4+9mJVK5UzP85YD6BHRX6tW5Vzbmei4TI//TQOywu8wMcfO/zAsAEKk5uHzKQcfAIdlg3BoP/54U+r+b2QW7rMdyA9HXqSj6l0ucvCVkG+G0WB2/G9ra2sHoFw3NH3s/I/AAiBE7l6x+Okbt+3+Z4X+ke0sMfA0oL0q0tsyLltuyS961XYgP/AindgZ8TyvaNbU4/D/9LHznwILgJDRavN/R3rsWkDbbGeJFMVrKuIKtKjQ3ju7l/zEdiS/HLEf/xpV70R+8cdGMZfLDZs15f7/aWLnfxQsAEJmQ37ByI19Oz+u4rgAmm3nCbFhhZYOXaTTHZ+LdAYH++aPjaW7MLEf/9erVZ4SGV9mx/8Wi8W5AK70OUwcsfM/BhYAIXTH8osfurFv1+dU8C+2s4RIDYqHFNLrqPaq11K+M79gxHYoPxSLxbmpVKoDh87VxxXCF/xEMN3/n07LSlVw6ufY2PkfBwuAkLpj+eKv3bht94UJXw9waOFeKlXbfFuu7XXbgfxwxEU6XQA6AOXvYuLoq9lsbrtJS8+T1SwSj4md/zTwSyfEzu+66L89U3riNKius52lMeRlBbYItNeTWu9dXW3P2k7kB1V1+vv7L+NFOnQ4EdkkhtNW3P9/TOz8p4k/QWGnKuu27f4yBJ+zHSUAQwotx/0AHlWsAnCq7UwULiJ6UybTeUe97SqVyjmq3nNBZIoBdv514AhA2InoBuAPbiw+/oqq/CWAlO1IphSoCjAgor1eLbV56PTxSlwu0unr6zsjnU5fhYmFe6urVSywnYnCzXGaek3aeZ53DYf/p8TOv078MYqQddsevwqQbwGYZztLHQ7N46PasmlDfsGbtgP5YYqLdC4Dj3Gm6duVzeaWmDR03dL/BuQjfgeKOHb+BlgARMzH+nbOT4nzTwJ82HaWo3hBoL0enM0p0d7buxa/YDuQH468SAcAL9KhGdCvZrOdv1d3K1WnUnFfAnBGAKGiip2/IRYAEXXjtsffr5CvAHi35Sj7RPGgQnsF6c13LF+403Ie3xwxj98D4BTbmSgu5APZbPb79bZyXfdyQGNzyJUP2PnPANcARNQd3UvuXa963zPF3b8F4C8BLGrEcyfn8bcD6HXg9O4/dbwvLvP4pVLpXSKyAhPz+NdWqzjPdiaKpaqIbDVryuN/D8POf4b4kxQD6wuF9NNN8z8iihsBXAV/FwoqgMcA7fXE6dUDI313X7P0gI+fb8327dvnDA0NZfGrefzLwd8JCpwWs9nObpOWrlvuBbDK50BRxM7fB/yyi5kb+/ac4Un1/3AgH1LFMghOq/MjPAB7AJQE2ptqqm65NXPpywFEbbgp5vGXg8ctU4Op4n/mcrm/qLddoVBobW1teR3ArABiRQk7f59wCiBm7li+8BcAbpn8Hz5e3HGeIPU+B9oGdU5T6MkQnAwPc0XwJiBvKvQNQJ4Vz3tkluc9+i/5trfs/lv454h5/KtVvZNY95JNpsf/zprVvFyVnT87f/+wAIi5ydP0ngXwPdtZGmFgYGBetVrtxsQ8/ppqFefYzkR0mH0tLS2DJg15/C87f7+xAKBIKxQKJ7S2tmYwOY9fq1UvF+ErPoWTCLa0t7ePm7WV1RNLchKJnX8AWABQpBQKhfSsWbOWHjaPvwJQ3opGEWE2/F8qld4F6Hv9ThMR7PwDwgKAQu+IefxrVb25nMenaEoZFQAi0oNk/tCz8w8QCwAKnWKxeJbjOJ2YmMd/f7WKs2xnIvLBzzOZzB6Thgm9/Y+df8BYAJB1g4ODp4+NjeUB9GCi07d9uiFRAMyG/yclbe8/O/8GYAFADVcul2eJSCcmF+6Nj49dJsKLdCjuHKMCwHXdJYCe63eaEGPn3yAsAChwUxzA0wVoq+1cRA3kjY+PFwybJmn4n51/A7EAoEAcsXBvlap3aoK+xIiO9PDy5ct/YdZUVvsbJbTY+TcYCwDyRV9f3xnpdPoqTMzhX12t4gLLkYhCQxVGw/+FQiGNiSOr446dvwUsAMjI9u3b5wwP71+h6vRgYvHeJeArPtHR9Jo0mj27Ket5ONHvMCHDzt8SLrwiI7t37x4B0i8D+jKAlwEYnW5GlADDAMomDWs1J+7D/+z8LeIbG/niiKt1fwPAxbYzEYWBCO7PZHLXmrR1XdcFNON3ppBg528ZCwAKxBGLAHsAnGI7E5ENIvrHmUznP9TbrlAonNza2vILxHOqlp1/CMTxB4tC4Moru5/C5LXEU2wDXA6g2W5CokYxO/63tbV1JaBx/I5m5x8SHAGghjtiuqAHwBW2MxEF5OVMJjtfROq+xs91y18D8OkAMtnEzj9E4lhdUsgtXbr0ACZWRfcCnC6gONNek85/UtwWALLzDxmOAFCocLqA4kXWZbPZO+tt5bruBYA+HUAgW9j5hxALAAo1ThdQlIk452YymefrbVeplG9Wxb8GkckCdv4hxSkACjVOF1CE7TTp/AHA87Ba4vF6xs4/xOLxI0aJxOkCCjNVfCWXy32u/nbqVCrllwE5PYhcDcTOP+RYACRUf3/p1z0P14vIFs/DD3K53F7bmWaK0wUUJo6j7+/o6PxBve1KpdKVjiMDQWRqIHb+EcACIMEqldKNqnIrAEcVT4nIvQC+PzIyUszn8yO2880UpwvIorGRkdHT8vn8W/U2dF33zwD96yBCNQg7/4hgAZBw5XL5t0VwN4DUYX97GEBpYgtTqrejo+OhGWxlCgVOF1AjiaAvk8mtMGnruuUCgKv8TVGNYxQAABCCSURBVNQw7PwjhAUAoVIp/RdVuRtHXxT6sgj6APRyuoBoOvSL2WznX9XbanBwcPb4+NjrAFoCCBU0dv4RwwKAAACu634E0H/DNHaGcLqA6Hgkk81m++tt5brurwF6XxCJAsbOP4JYANAhruuuBfQbqG97KKcLiA4jgjefffb509euXVurt63rlr8M4A8CiBUkdv4RxQKA3sawCDjcKyLYCk4XUGLJd7LZ7IdNWrpu+TEAl/gcKEjs/COMBQC9Q7lcvk4E34QPB0XFcbqgv79/gWptNThdQFNQxadzuVzdp/gNDAzMq9WqLyA638vs/CMuKj9o1GCVSunDqvJNAE0+fiynCyj20unahZPXYdelUildryp3BZEpAOz8Y4AFAB1VpVL6LVX5FvwtAg7H6QKKm2ey2dwCk4blcvkuEVzvd6AAsPOPCRYAdEyu6/4moP8bwRUBh8RxumBwsG/+2Fh6tePg/apYBeBU25koOCL410wm9+l626mquK67VwTzg8jlI3b+McICgI5r4thg+Q4auzeZ0wUUOSL64Uym8zv1tiuVSpc4jjwWRCYfsfOPGRYANC2VSnGNqvPvsHdACacLKOxqqnhXLpd7vd6Gruv+AaBfDiKUT9j5xxALAJq2yUNK/h1Aq+0snC6gECpns7lOk4auW74PwK/5nMcv7PxjigUA1SVMRcBhOF1AISB/ns1m/6beVjt27Gjet++XrwE4IYBQM8XOP8ZYAFDdyuXytSL4LsJVBBwudtMFlUrlRKCWV3WuBnQ1gIW2M9HbiThtmUxmZ73tXNe9CtBCAJFmip1/zLEAICOTawK+g/AWAQcpgEcA3aQqD4yOjpY4XUD+k0o2m82atKxUyn+jii/4nWiGflKt1lZ3d3e/YTsIBYcFABmrVEpXq8p/AJhlO0sdYjpdcNaVgLNaVa8GJAMfTnGkesinstnsrSYtXbe8A8DFPgeaCb75JwQLAJqRiBYBh4vddAF3FzSWKl4EcGEulxuut22lUlmo6j0RQCxT7PwThAUAzVi5XF4hgh8AmGM7y0yp4ikAvSJy78jIyKY4TBe4rnuBiF7teVgtglXg3QU+k9/LZrNfNWnpuqXPA/IlvxMZYuefMCwAyBeu6/YA+p8AZtvO4qMhEWxTlQdUdVMulwv7QS3Hxd0FvtvzxhtvXrpmzZpRk8aVSvlhVbzP71AGOOefQCwAyDf9/cVuz3PuQzi3M/mB0wV0BFmTzWZ/aNKyUilmVB3X70QG+OafUCwAyFcJKAIOieN0AXcX1EO+ns1mbzZt7bqlOwBZ52MgE+z8E4wFAPkuTmsC6jAsgr64TRece+657YetH8iCuwsO2tnU1Hxle3v7kEnj/v7+0zyv9izsTplx2D/hWABQIFzX7QT0hwDm2s5iyaHpAsC5L5PJPG870ExxuuCQ1xwnlevo6DBevV8ul/9WBH/qZ6g68c2fWABQcFgE/Eocpwtc170A8FarytUJ2l0wBMjV2Wy2ZPoBg4ODp4+Pjz0Fe78X7PwJAAsAClilUulS9e4Di4DDDYugD9BNnicPxGG6QFWd/v7+y2K+u+CAKj6Yy+U2z+RDXNf9e0D/yK9QdeKwPx3CAoACVy6XcyL4IYATbWcJqdhNFxSLxbmpVCqvqleL6GpALrKdaYZe8Tz9UGdn54xW7U8e/PMY7FyrzTd/ehsWANQQlUrlClVvE5IxTDwjCZguWIkI7S4QwSO1mn6os7Pz5zP9LNct9wJY5UOserHzp3dgAUANM7nv+UcATrKdJUKGVbHNcfQBILWpo6PjsajfXRCh6QJVxdebm5v/wHS1/+Fc1/0ooP/mR7A6cdifpsQCgBrKdd3LAd2ECL0BhkxspwsmrjnWq0MyXfBjEe/3Mpmuih8fNjAwcG6tVn0YwGl+fF4d+OZPR8UCgBqORYB/Dk4XAOgdHR39YT6ff8t2ppkqlUrnOw6uFpHVFg4j2imif9vRkfumiHh+fGChUEi3trY8CKDTj8+rAzt/OiYWAGRFf3+x3fOcB8A1AX6K3XTBxo0bU+ecc84VInqwIMgCaPL5MVUAPwLk65lM5l6/Ov6DXNf9EqCf9/Mzp4HD/nRcLADImlKp9D7HkV40flg0KZIwXbAQZt9j+1RREJEfNTWN/2d7+/IX/c4KAK7rrgP0jiA++xj45k/TwgKArJooArAJkNNtZ4m7w6cLPM/7UVdX137bmWaqWCzOTafRppq6BNCLAT0FkJNUcRKAE0XwJoARQF9SlecA7AHwcDabfcLvN/0jTR6JfT8au+WPnT9NGwsAso4jAVZMThdgE+A8EIfpgjAplUpXOo5sQmN3vHDYn+rCAoBCob9/21LPc3o5EmDNL0TwIGI0XWDL5PqW+9HYxYt886e6sQCg0KhUKu9V9XoBnGE7S8IpII+q6ibHcR7wPK+Yy+WGbYeKgslh/++jsUdf882fjLAAoFApl8uLAWwRwXzbWeiQYQAlQHtFUr0dHR0Pcbrgncrl8m+L4HYArQ18LN/8yRgLAAqdgYFiW63mbAZwpu0sNKWXVLHJcXST4zRtWrZs2Uu2A9k0uVXxSyL44wY/mm/+NCMsACiUisXiolTK2QLgLNtZ6NjiuLtguiYOLZI7Aaxo8KP55k8zxgKAQst13SWAbgEwz3YWmrZhQIsi8oBIbdOyZV2PxnW6YHKP/1fQ+Fsu+eZPvmABQKHW399/0f/fzr3FyFnXYRx//u/sbnEx0F5AjXRLBLkga7IXjtOZ2RadNiVaKjFR1mhVtN6RSsAYDIoHJBI8XKBivFIUSQwroRGhgVa7pt3dmWx7Ya1rUiM3bokUoy2l9LQ778+LWQ2ptN3DzPzew/eT9Hbn6dXz7O99Z+O4OSYuAWmVuW8XzF+nHpX0QYeP5zd/tA0DAInH44DMMEmHzbQ7imxPHIf9afp2wb59+67p7e19QLK7JPU4ROA3f7QVAwCp0Gg0bjKLxyRd550FbXNW0njSv13QaDRWm9m9kn1BUr9TDH7zR9sxAJAa8yNgr6Q13lnQEceksCeEeLf3twvMLExNTdbiWNulcIekPq8s4jd/dAgDAKkyOTn57hBsrxQGvLOgo0zS4f8OgjNnzu+r1WpnO/qBZtHk5OR7C4WwNY71qRB0Qyc/b4Eof3QMAwCpMzExcWMUhb2S1npnQde8HoKek2xPHIfpvr6+I8Vi8bXl/MCxsbGe/v6ewTjueZ9k69V6qS9Jf3uC8kdHMQCQSgcO7L9hbq6wV9L13lng5lUzHQlBfzXTS1Gkf0l2Mo7DqRDCqShqnorjwsooilc0m6Ff0uoo0lozXS/pXZLeI+ltvv+Fi6L80XEMAKTW+Pj42iiKxhJyqgXahRf+0BWRdwBgqdavX//3OI5rkl7yzgK0CeWPruECgNSbmpoaaDbnxiTd6J0FWAbKH13FBQCpVyqVZgqFnpqkv3lnAZaI8kfXMQCQCaVSaSaEiBGANKL84YJHAMiUqampdzSbc3sl3eydBVgAyh9uuAAgU0ql0iuFQs9GSX/xzgJcBuUPVwwAZE6pVHolhIgRgCSj/OGOAYBMKpfLx0KINppp2jsLcAHKH4nAAEBmlcvlY2a2UdKfvbMA8yh/JAYvASLzJiYmro2i8Hu1/vQr4IXyR6JwAUDmDQ8PvxrHtknSYe8syC3KH4nDAEAuDA8Pvzo7O8cIgAfKH4nEAEBu3HLLLf+cHwF/8s6C3KD8kVi8A4Dc2b9//6pCobA7BBW9syDTKH8kGgMAucQIQIdR/kg8HgEglzZs2HD83LlzmyUd8M6CzKH8kQoMAORWrVY7cfbsuVslTXlnQWZQ/kgNHgEg98bGxlZeccWKFyWVvLMg1Sh/pAoDAJB08ODBq2dnz78oaZ13FqQS5Y/UYQAA81ojYPYFycreWZAqlD9SiQEAvAkjAItE+SO1GADABQ4dOnTl6dNvPC/p/d5ZkGiUP1KNbwEAFxgaGnqjv//K2yT9wTsLEovyR+pxAQAuYv4S8JykD3hnQaJQ/sgEBgBwCa0RcPq3ktW8syARKH9kBo8AgEsYGhp6o7e3d6sUxryzwB3lj0xhAACXUSwWT/f29m41017vLHBD+SNzeAQALNDBgwf7Z2fPPytpk3cWdBXlj0ziAgAsUOsS0He7pN95Z0HXUP7ILAYAsAjFYvG0mRgB+UD5I9MYAMAiVavVM8ePn9hqpue9s6BjKH9kHgMAWIItW7acO3HixEclPeedBW1H+SMXeAkQWIbp6em+kydfe1rSh72zoC0of+QGFwBgGQYHB89fddXVH5PsWe8sWDbKH7nCBQBog9Yl4MSvpXC7dxYsCeWP3OECALRB6xKw8g4z/cY7CxaN8kcucQEA2mh6errv9ddfe8pMH/HOggWh/JFbXACANhocHDzf09M3ImmndxZcFuWPXGMAAG1WLBZne3v7Pi7pGe8suCjKH7nHAAA6oFgszs7MHB0JQb/yzoL/Q/kD4h0AoKNGR0cLAwNrnpD0Se8skET5A//DAAA6rDUCrvuFFLZ5Z8k5yh94Ex4BAB02MjLSnJl5+U4pPOmdJccof+ACXACALhkdHS2sWbPm8RD0ae8sOUP5A2+BCwDQJSMjI82jR49+LgQ94Z0lRyh/4CK4AABdNv9i4E8l3emdJeMof+ASGACAAzOLGo36z8QI6BTKH7gMHgEADkIIcblc2S7Zz72zZBDlDywAAwBw0hoB1e2S/cQ7S4ZQ/sAC8QgAcGZmodFoPCbZXd5ZUo7yBxaBAQAkACNg2Sh/YJF4BAAkQAjByuXyDjP92DtLClH+wBJwAQASpHUJqP9Q0g7vLClB+QNLxAUASJDWJaByt2Q/8s6SApQ/sAxcAIAEmn8n4FHJ7vbOklCUP7BMXACABJp/J+AeM/3AO0sCUf5AGzAAgIQKIVi1Wr3HTI94Z0kQyh9oEx4BACnQaEw+bKb7vXM4o/yBNuICAKRAuVz9imQPe+dwRPkDbcYAAFKiUhn+qmTf9s7hgPIHOoBHAEDK1Ov1hyR7wDtHl1D+QIdwAQBSplKpfM1MD3nn6ALKH+ggLgBASjUakw+a6eveOTqE8gc6jAsAkFLlcvUbkj3onaMDKH+gC7gAAClXr098WQpZ+VsBlD/QJQwAIAMyMgIof6CLGABARtTr9fsk+453jiWi/IEu4x0AICMqlcp3zXSfd44loPwBB1wAgIxpNCa/ZKbveedYIMofcMIFAMiYcrn6fTPdK8m8s1yKmfbPzTU3Uf6ADy4AQEbV6/Vtkj0uqdc7y1vYaaZt1Wr1jHcQIK8YAECGNRoTt5qFJyVd451lXtNMD1cqlW+GEGLvMECeMQCAjGs0GqvNmr+UwmbnKMdCsM+Uy8O7nXMAEO8AAJlXLpePzcy8/CEz7ZB03CFCU9Jjc3PNmyl/IDm4AAA5MjExcW2hEL5lps9KWtHhjzNJL0RR8/516zYc6vBnAVgkBgCQQ+Pj4+8sFApfDME+b6aVbf7x5yXbGcd6ZHh4+I9t/tkA2oQBAOTYrl27Vqxateo2M/tECNos6eol/qizZpqMIj0Vx3q6Wq3+u505AbQfAwCAJGl0dLQwMDAwJMXrpXCzpJskrZVslRTertbXCU+2/oV/SHbETEeiKG6cOTNbr9VqZ13/AwAW5T/rJDMCw1sNugAAAABJRU5ErkJggg==">
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:system-ui,sans-serif;background:#f0f2f8;color:#1a1a2e;padding:40px 24px}
.wrap{max-width:720px;margin:0 auto}
.back{display:inline-block;margin-bottom:24px;font-size:13px;color:#8891b0;text-decoration:none}
.back:hover{color:#555}
.card{background:#fff;border:1px solid #dde2f0;border-radius:14px;padding:40px;
      box-shadow:0 4px 20px rgba(0,0,0,.08)}
${css ?? ''}
</style></head><body><div class="wrap">`;
}
const shellEnd = `</div></body></html>`;

function downloadPage(release) {
  const { tag_name, published_at, body, html_url, assets } = release;
  const date = new Date(published_at).toLocaleDateString('en-US', { year:'numeric', month:'long', day:'numeric' });

  const standaloneAsset = assets.find(a => a.name.endsWith('.html'));
  const zipAsset        = assets.find(a => a.name.endsWith('.zip'));

  const dlBtn = (href, label, sub, dl = true) =>
    `<a class="dl-btn" href="${esc(href)}"${dl ? ' download' : ''} target="_blank" rel="noopener">
      <span>${esc(label)}</span><span class="sub">${esc(sub)}</span></a>`;

  const links = [
    standaloneAsset
      ? dlBtn(standaloneAsset.browser_download_url, `Download ${tag_name} — Standalone`,
              `${(standaloneAsset.size/1024).toFixed(0)} KB · No scraper required`)
      : dlBtn(html_url, `Download ${tag_name}`, 'GitHub release page', false),
    zipAsset
      ? dlBtn(zipAsset.browser_download_url, `Download ${tag_name} — Scraper Included`,
              `${(zipAsset.size/1024).toFixed(0)} KB · Includes local scraper for Quizlet URL import`)
      : '',
  ].join('\n');

  const notes = body ? `<pre class="notes">${esc(body.trim())}</pre>` : '';

  return shell(`
    .label{font-size:11px;font-weight:700;letter-spacing:.08em;text-transform:uppercase;color:#8891b0;margin-bottom:10px}
    h1{font-size:30px;font-weight:700;margin-bottom:4px}
    .date{font-size:13px;color:#8891b0;margin-bottom:28px}
    .dl-btn{display:flex;align-items:center;justify-content:space-between;padding:13px 18px;
            background:#1a1a2e;color:#fff;text-decoration:none;border-radius:8px;font-weight:600;
            font-size:14px;margin-bottom:8px;transition:background .15s}
    .dl-btn:hover{background:#2d2d4e}
    .sub{font-size:12px;opacity:.55;font-family:monospace;font-weight:400;text-align:right;max-width:55%}
    .notes{font-size:12px;color:#555;background:#f7f8fc;border:1px solid #e4e8f4;border-radius:6px;
           padding:14px;margin-top:20px;white-space:pre-wrap;word-break:break-word;
           max-height:180px;overflow-y:auto;line-height:1.6}
    .bottom-links{display:flex;justify-content:center;align-items:center;gap:1.5rem;margin-top:18px}
    .gh-link,.docs-link{font-size:13px;color:#8891b0;text-decoration:none}
    .gh-link:hover,.docs-link:hover{color:#555}
  `) + `
  <div class="card">
    <div class="label">FlashBuddy</div>
    <h1>${esc(tag_name)}</h1>
    <div class="date">Released ${date}</div>
    ${links}
    ${notes}
    <div class="bottom-links">
      <a class="gh-link" href="https://github.com/${esc(GITHUB_REPO)}" target="_blank" rel="noopener">View on GitHub →</a>
      <a class="docs-link" href="/docs">How to Use →</a>
    </div>
  </div>` + shellEnd;
}

function errorPage(msg) {
  return shell() + `<div class="card" style="text-align:center">
    <h1 style="font-size:18px;margin-bottom:10px">Unavailable</h1>
    <p style="color:#666;font-size:13px;line-height:1.5">${esc(msg)}</p>
  </div>` + shellEnd;
}

function docsIndexPage(files) {
  const items = files.map(f => {
    const slug = f.replace(/\.md$/, '');
    const title = slug.replace(/-/g, ' ').replace(/\b\w/g, c => c.toUpperCase());
    return `<a class="doc-item" href="/docs/${esc(slug)}">${esc(title)}</a>`;
  }).join('');
  return shell(`
    h1{font-size:28px;font-weight:700;margin-bottom:6px}
    .sub{font-size:14px;color:#8891b0;margin-bottom:28px}
    .doc-item{display:block;padding:14px 18px;background:#fff;border:1px solid #dde2f0;
              border-radius:8px;margin-bottom:8px;text-decoration:none;color:#1a1a2e;
              font-weight:600;font-size:15px;transition:border-color .15s}
    .doc-item:hover{border-color:#a0a8d0}
    .home{display:block;text-align:center;margin-top:18px;font-size:13px;color:#8891b0;text-decoration:none}
    .home:hover{color:#555}
  `) + `
  <h1>FlashBuddy Docs</h1>
  <p class="sub">How to navigate the app and use more advanced features.<br>Start by clicking on an article!</p>
  ${items}
  <a class="home" href="/download">← Back to Download</a>` + shellEnd;
}

function docsPage(title, mdContent) {
  return shell(`
    h1{font-size:28px;font-weight:700;margin-bottom:20px}
    h2{font-size:20px;font-weight:600;margin:28px 0 12px}
    h3{font-size:16px;font-weight:600;margin:20px 0 8px}
    p{font-size:15px;line-height:1.7;margin-bottom:14px;color:#333}
    pre{background:#f7f8fc;border:1px solid #e4e8f4;border-radius:6px;padding:14px;
        margin-bottom:14px;overflow-x:auto}
    code{font-family:monospace;font-size:13px;background:#f0f2f8;padding:2px 5px;border-radius:3px}
    pre code{background:none;padding:0}
    ol,ul{margin:0 0 14px 24px}
    li{font-size:15px;line-height:1.7;margin-bottom:4px}
    a.back{display:inline-block;margin-bottom:24px;font-size:13px;color:#8891b0;text-decoration:none}
    a.back:hover{color:#555}
    strong{font-weight:600}
  `) + `
  <a class="back" href="/docs">← Docs</a>
  <div class="card">${marked.parse(mdContent)}</div>` + shellEnd;
}
// ─────────────────────────────────────────────

app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'GET, OPTIONS');
  if (req.method === 'OPTIONS') return res.sendStatus(204);
  next();
});

app.get('/scrape', async (req, res) => {
  const url = req.query.url;
  if (!url || !url.includes('quizlet.com')) {
    return res.status(400).json({ error: 'Invalid Quizlet URL' });
  }

  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');
  res.flushHeaders();

  const send = (type, payload = {}) =>
    res.write(`data: ${JSON.stringify({ type, ...payload })}\n\n`);

  send('log', { msg: 'Connection established' });

  let browser;
  try {
    send('log', { msg: 'Launching browser…' });
    const puppeteer = require('puppeteer');
    browser = await puppeteer.launch({
      headless: true,
      args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-blink-features=AutomationControlled'],
    });

    send('log', { msg: 'Navigating to Quizlet…' });
    const page = await browser.newPage();
    await page.setUserAgent(
      'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36'
    );
    await page.evaluateOnNewDocument(() => {
      Object.defineProperty(navigator, 'webdriver', { get: () => undefined });
    });

    try {
      await page.goto(url, { waitUntil: 'domcontentloaded', timeout: 30000 });
    } catch (e) {
      if (!e.message.includes('timeout')) throw e;
    }

    await page.evaluate(() => {
      for (const sel of ['[data-testid="cookie-banner-accept"]', 'button[aria-label*="Accept"]'])
        document.querySelector(sel)?.click();
    });

    send('log', { msg: 'Waiting for cards to appear…' });
    await page.waitForSelector('[aria-label="Term"]', { timeout: 30000 });

    send('log', { msg: 'Scraping…' });
    const seen = new Map();

    const collectPage = () => page.evaluate(() => {
      return Array.from(document.querySelectorAll('[aria-label="Term"]')).map(item => {
        const sides = item.querySelectorAll('[data-testid="set-page-term-card-side"]');
        const term = sides[0]?.querySelector('.TermText')?.textContent?.trim() ?? '';
        const def  = sides[1]?.querySelector('.TermText')?.textContent?.trim() ?? '';
        return { term, def };
      }).filter(c => c.term && c.def);
    });

    let stable = 0, lastReported = 0;
    while (stable < 4) {
      const batch = await collectPage();
      const before = seen.size;
      batch.forEach(c => { if (!seen.has(c.term)) seen.set(c.term, c); });
      stable = seen.size === before ? stable + 1 : 0;
      if (seen.size !== lastReported && seen.size > 0) {
        send('log', { msg: `Scraping… ${seen.size} cards collected` });
        lastReported = seen.size;
      }
      await page.evaluate(() => window.scrollBy(0, window.innerHeight * 2));
      await new Promise(r => setTimeout(r, 500));
    }
    (await collectPage()).forEach(c => { if (!seen.has(c.term)) seen.set(c.term, c); });

    const cards = [...seen.values()];
    if (cards.length === 0) {
      send('error', { msg: 'No cards found — deck may be private or Quizlet changed their HTML.' });
      return res.end();
    }

    const name = await page.evaluate(() => {
      for (const el of [document.querySelector('h1'), document.querySelector('[data-testid="set-title"]')]) {
        if (el?.textContent?.trim()) return el.textContent.trim().replace(/\s*[-|]\s*Quizlet.*/i, '').trim();
      }
      return document.title.replace(/\s*[-|]\s*Quizlet.*/i, '').trim();
    });

    send('done', { name, cards });
  } catch (err) {
    console.error(err);
    send('error', { msg: err.message });
  } finally {
    if (browser) await browser.close();
    res.end();
  }
});

app.get('/', (req, res) => res.redirect('/download'));

app.get('/download', async (req, res) => {
  try {
    const apiRes = await fetch(
      `https://api.github.com/repos/${GITHUB_REPO}/releases/latest`,
      { headers: { Accept: 'application/vnd.github.v3+json', 'User-Agent': 'FlashBuddy' } }
    );
    if (apiRes.status === 404) return res.status(404).send(errorPage('No releases found for this repo.'));
    if (!apiRes.ok) return res.status(502).send(errorPage(`GitHub API returned ${apiRes.status}.`));
    res.send(downloadPage(await apiRes.json()));
  } catch (err) {
    res.status(502).send(errorPage(`Could not reach GitHub: ${err.message}`));
  }
});

app.get('/docs', (req, res) => {
  try {
    const files = fs.readdirSync(DOCS_DIR).filter(f => f.endsWith('.md')).sort();
    res.send(docsIndexPage(files));
  } catch {
    res.status(500).send(errorPage('Docs not found.'));
  }
});

app.get('/docs/:name', (req, res) => {
  const name = path.basename(req.params.name);
  const file = path.join(DOCS_DIR, name + '.md');
  if (!fs.existsSync(file)) return res.status(404).send(errorPage('Doc not found.'));
  const content = fs.readFileSync(file, 'utf8');
  const title   = name.replace(/-/g, ' ').replace(/\b\w/g, c => c.toUpperCase());
  res.send(docsPage(title, content));
});

app.listen(PORT, () =>
  console.log(`FlashBuddy scraper listening on http://localhost:${PORT}`)
);

module.exports = app;
